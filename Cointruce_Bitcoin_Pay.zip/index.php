<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
	#	Bitcoin Payment with Cointruce module for Sendroid Ultimate
	#	location: gateway/cointruce/index.php
	#	Developed by: Ynet Interactive
	#	Special thanks: Mr. White

*/
global $LANG;
global $configverssion_id;
global $configapp_version;
global $server;
$userID = getUser();
$resellerID = userData($userID,'reseller');
global $userID;
global $resellerID;

class PaymentGateway {
	function curl_get_contents($url){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_URL, $url);
		$data = curl_exec($ch);
		curl_close($ch);
		return $data;
	}

	function getBTCRate($from='BTC',$to='USD') {
	  set_time_limit(0);
	  $url = "https://bitpay.com/api/rates";
	  $url = "https://api.coinbase.com/v2/exchange-rates?currency=".$from;
	  $json = $this->curl_get_contents($url);
	  $data = json_decode($json, TRUE);
	  $rate = $data['data']["rates"][$to];    
	  return $rate;
	}

	function initiatePayment($transaction_reference,$amount,$user_id,$button='') {
		global $LANG;
		$gateway = transactionData($transaction_reference,'method');	//Get the gateway ID from transaction
		$currency = paymentGatewayData($gateway,'currency_id');			//get the currency for this gateway
		$user_currency = userData($user_id,'currency_id');				//The users currency
		$currency_code = currencyCode($user_currency);					//set user currency code if needed
		$amount_converted = $amount*currencyRate($currency);			//Convert amount to charge to gateway's currency
		if($currency_code==$currency) {
			$amount_converted = $amount;								// No conversion needed
		}
		//convert to Bitcoins
		$btcrate = $this->getBTCRate('USD','BTC');
		$amount_converted = round($amount_converted * $btcrate,8);
		$secret_key = trim(paymentGatewayData($gateway,'param2'));			//Cointruce stores secret_key in param2 column
		$site_key = trim(paymentGatewayData($gateway,'param1'));			//Cointruce stores merchant_id in param1 column
		//build HTML form
		$out = '';
		$out .= '<form action="https://www.cointruce.com/pay/" method="post">
        <input type="hidden" name="p_amount" value="'.$amount_converted.'">
        <input type="hidden" name="p_merchant_key" value="'.trim($site_key).'">
        <input type="hidden" name="p_tranx_reference" value="'.$transaction_reference.'">
        <input type="hidden" name="p_callback_url" value="'.home_base_url().'gateway/'.paymentGatewayData($gateway,'type').'/callback.php?tx_reference='.$transaction_reference.'">
        <input type="hidden" name="p_customer_pay_charge" value="1">
        <input type="hidden" name="p_return_url" value="'.home_base_url().'gateway/'.paymentGatewayData($gateway,'type').'/callback.php?tx_reference='.$transaction_reference.'">
        <input type="hidden" name="p_customer_id" value="'.userData($user_id,'email').'">
        <input type="hidden" name="p_custom_param" value="">
        <input type="hidden" name="p_action" value="pay">
	'. $button.'
    </form>';
		return $out;	  
	}
	function validatePayment($transaction_reference,$amount,$user_id,$postdata='') {
		//Not required for paytabs
	}	
}