<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
	#	Cointruce hook for Sendroid Ultimate
	#	Developed by: Ynet Interactive
	#	Special thanks: Mr. White
*/
global $LANG;
global $configverssion_id;
global $configapp_version;
global $server;

?>