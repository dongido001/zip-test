<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
	#	Bitcoin Payment with Cointruce for Sendroid Ultimate
	#	Developed by: Ynet Interactive
	#	Special thanks: Mr. White
*/
global $LANG;
global $configverssion_id;
global $configapp_version;
global $server;

//Create Payment Gateway Template
mysqli_query($server,"INSERT INTO `paymentgateway_templates` (`title`, `alias`, `image`, `param3_label`, `param4_label`, `currency_id`, `param1_label`, `param2_label`, `hide_pay_button`, `module_id`, `status`) VALUES ('Bitcoin Payment with Cointruce.com', 'cointruce', 'cointruce.png', '', '', 'USD', 'Cointruce API Key', 'Cointruce API Token', 0, '0', 1)");

?>